# ----------------------------------------------------------------------
# exists.R
#
# METHOD: exists( hash, key )
#
# DEPRECATED and unused
#  ---------------------------------------------------------------------- 

#setGeneric( "exists", function( x, where ) standardGeneric( "exists" ) )
#setMethod( 
#    "exists" , 
#    signature( "ANY", "hash" ) ,
#    function( x, where, ... ) {
#        key <- validate.key(key)
        # sapply( key, exists, hash@env )
		# return(key)
#		sapply( x, exists, where@env, ... )
#    }
#)
#
