
library(hash)
h <- hash( letters, 1 )
keys(h)   # 26
clear(h)
keys(h)   # 0

